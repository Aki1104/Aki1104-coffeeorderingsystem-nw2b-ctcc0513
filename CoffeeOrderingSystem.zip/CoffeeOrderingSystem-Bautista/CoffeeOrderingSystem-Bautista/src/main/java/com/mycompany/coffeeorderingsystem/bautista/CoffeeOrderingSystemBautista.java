package com.mycompany.coffeeorderingsystem.bautista;

/**
 *
 * @author veeny
 */
public class CoffeeOrderingSystemBautista {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
